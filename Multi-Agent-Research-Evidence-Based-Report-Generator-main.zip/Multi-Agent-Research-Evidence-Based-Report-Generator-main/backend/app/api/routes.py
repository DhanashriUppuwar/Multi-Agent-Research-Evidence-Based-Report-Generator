# backend/app/api/routes.py
from fastapi import APIRouter, HTTPException
from pathlib import Path
from datetime import datetime
from app.schemas.report import ReportRequest, ReportResponse
from app.config.settings import get_settings
from app.graph.workflow import build_graph

router = APIRouter()


@router.post("/generate-report", response_model=ReportResponse)
def generate_report(payload: ReportRequest):
    try:
        graph = build_graph()
        result = graph.invoke(
            {
                "topic": payload.topic,
                "outline": {},
                "research_status": {},
                "coverage_score": 0.0,
                "verified": False,
                "retry_count": 0,
                "report": "",
                "citations": [],
                "report_id": "",
                "outputs": {},
            }
        )
        return ReportResponse(
            topic=payload.topic,
            report=result.get("report", ""),
            citations=result.get("citations", []),
            coverage_score=result.get("coverage_score", 0.0),
            verified=result.get("verified", False),
            report_id=result.get("report_id", ""),
            outputs=result.get("outputs", {}),
            research_status=result.get("research_status", {}),
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@router.get("/history")
def report_history():
    settings = get_settings()
    output_dir = Path(settings.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    items = []
    for md_file in sorted(output_dir.glob("report_*.md"), key=lambda p: p.stat().st_mtime, reverse=True):
        pdf_file = md_file.with_suffix(".pdf")
        items.append(
            {
                "name": md_file.name,
                "markdown": str(md_file),
                "pdf": str(pdf_file) if pdf_file.exists() else "",
                "updated_at": datetime.fromtimestamp(md_file.stat().st_mtime).isoformat(),
            }
        )
    return {"items": items}


@router.get("/history/{name}")
def report_history_item(name: str):
    if ".." in name or "/" in name or "\\" in name:
        raise HTTPException(status_code=400, detail="Invalid report name.")
    if not name.startswith("report_") or not name.endswith(".md"):
        raise HTTPException(status_code=400, detail="Invalid report name.")

    settings = get_settings()
    output_dir = Path(settings.output_dir)
    path = output_dir / name
    if not path.exists() or not path.is_file():
        raise HTTPException(status_code=404, detail="Report not found.")

    pdf_path = path.with_suffix(".pdf")
    return {
        "name": path.name,
        "content": path.read_text(encoding="utf-8"),
        "pdf": str(pdf_path) if pdf_path.exists() else "",
        "updated_at": datetime.fromtimestamp(path.stat().st_mtime).isoformat(),
    }
