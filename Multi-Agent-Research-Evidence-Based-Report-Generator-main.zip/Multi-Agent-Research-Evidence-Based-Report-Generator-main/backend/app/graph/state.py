# backend/app/graph/state.py
from typing import Any, Dict, List, TypedDict


class ResearchState(TypedDict):
    topic: str
    outline: Dict[str, Any]
    research_status: Dict[str, Any]
    coverage_score: float
    verified: bool
    retry_count: int
    report: str
    citations: List[str]
    report_id: str
    outputs: Dict[str, str]
