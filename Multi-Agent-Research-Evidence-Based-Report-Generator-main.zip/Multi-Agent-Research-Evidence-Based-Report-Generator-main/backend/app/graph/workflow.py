# backend/app/graph/workflow.py
import json
import logging
import os
from typing import Dict
from uuid import uuid4

from langgraph.graph import END, StateGraph

from app.agents.planner import plan_outline
from app.agents.researcher import research
from app.agents.verifier import verify
from app.agents.writer import write_report
from app.config.settings import get_settings
from app.graph.state import ResearchState
from app.tools.exporter import export_report

logger = logging.getLogger("research_graph")
if not logger.handlers:
    logging.basicConfig(level=logging.INFO)


def _persist_state(state: Dict, stage: str, state_dir: str):
    os.makedirs(state_dir, exist_ok=True)
    report_id = state.get("report_id", "unknown")
    path = os.path.join(state_dir, f"{report_id}_{stage}.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2)


def planner_node(state: ResearchState):
    settings = get_settings()
    report_id = state.get("report_id") or uuid4().hex
    update = plan_outline(state)
    update["report_id"] = report_id
    _persist_state({**state, **update}, "planner", settings.state_dir)
    return update


def researcher_node(state: ResearchState):
    settings = get_settings()
    update = research(state)
    _persist_state({**state, **update}, "researcher", settings.state_dir)
    return update


def verifier_node(state: ResearchState):
    settings = get_settings()
    update = verify(state)
    _persist_state({**state, **update}, "verifier", settings.state_dir)
    return update


def writer_node(state: ResearchState):
    settings = get_settings()
    update = write_report(state)
    outputs = export_report(
        state["topic"], update.get("report", ""), settings.output_dir, settings.export_pdf
    )
    update["outputs"] = outputs
    _persist_state({**state, **update}, "writer", settings.state_dir)
    return update


def _decide_next(state: ResearchState):
    settings = get_settings()
    if state.get("verified"):
        return "writer"
    if state.get("retry_count", 0) >= settings.max_retries:
        return "writer"
    return "researcher"


def build_graph():
    graph = StateGraph(ResearchState)
    graph.add_node("planner", planner_node)
    graph.add_node("researcher", researcher_node)
    graph.add_node("verifier", verifier_node)
    graph.add_node("writer", writer_node)

    graph.set_entry_point("planner")
    graph.add_edge("planner", "researcher")
    graph.add_edge("researcher", "verifier")
    graph.add_conditional_edges(
        "verifier",
        _decide_next,
        {
            "researcher": "researcher",
            "writer": "writer",
        },
    )
    graph.add_edge("writer", END)

    return graph.compile()
