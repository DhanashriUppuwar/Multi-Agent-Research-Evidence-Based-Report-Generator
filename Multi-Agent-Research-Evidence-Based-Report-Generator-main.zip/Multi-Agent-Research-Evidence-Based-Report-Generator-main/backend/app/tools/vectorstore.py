# backend/app/tools/vectorstore.py
import os
import re
from typing import Any, Dict, List, Optional
from uuid import uuid4

import chromadb

from app.config.settings import get_settings
from app.tools.embedding import embed_texts


def _ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)


def _sanitize_collection_name(topic: str) -> str:
    safe = re.sub(r"[^a-zA-Z0-9_-]", "-", topic.strip().lower())
    safe = safe.strip("-")
    return safe[:50] if safe else "default"


def _get_client():
    settings = get_settings()
    _ensure_dir(settings.chroma_persist_dir)
    return chromadb.PersistentClient(path=settings.chroma_persist_dir)


def get_collection(topic: str):
    client = _get_client()
    name = _sanitize_collection_name(topic)
    return client.get_or_create_collection(name=name)


def store_embeddings(topic: str, chunks: List[str], metadatas: List[Dict[str, Any]]):
    if not chunks:
        return 0
    collection = get_collection(topic)
    embeddings = embed_texts(chunks)
    ids = [f"{_sanitize_collection_name(topic)}-{uuid4().hex}" for _ in chunks]
    collection.add(documents=chunks, embeddings=embeddings, metadatas=metadatas, ids=ids)
    return len(chunks)


def query_chunks(
    topic: str,
    query_text: str,
    n_results: int = 5,
    where: Optional[Dict[str, Any]] = None,
) -> List[Dict[str, Any]]:
    collection = get_collection(topic)
    embeddings = embed_texts([query_text])
    result = collection.query(
        query_embeddings=embeddings,
        n_results=n_results,
        where=where,
        include=["documents", "metadatas", "distances"],
    )

    docs = result.get("documents", [[]])[0]
    metas = result.get("metadatas", [[]])[0]
    dists = result.get("distances", [[]])[0]

    items: List[Dict[str, Any]] = []
    for doc, meta, dist in zip(docs, metas, dists):
        items.append({"document": doc, "metadata": meta, "distance": dist})
    return items
