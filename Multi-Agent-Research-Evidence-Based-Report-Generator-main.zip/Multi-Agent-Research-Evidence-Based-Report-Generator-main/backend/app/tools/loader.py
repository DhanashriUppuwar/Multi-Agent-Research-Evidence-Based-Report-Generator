# backend/app/tools/loader.py
import asyncio
from typing import Dict, List

import httpx
import requests
from bs4 import BeautifulSoup


_DEFAULT_HEADERS = {"User-Agent": "Mozilla/5.0 (compatible; ResearchBot/1.0)"}


def _clean_html(html: str) -> str:
    soup = BeautifulSoup(html, "html.parser")
    for tag in soup(["script", "style", "noscript"]):
        tag.decompose()
    text = soup.get_text(separator=" ")
    return " ".join(text.split())


def load_web_page(url: str, timeout: int = 15) -> str:
    """Load a web page and return cleaned text content."""
    resp = requests.get(url, headers=_DEFAULT_HEADERS, timeout=timeout)
    resp.raise_for_status()
    return _clean_html(resp.text)


async def load_web_pages(urls: List[str], timeout: int = 15) -> Dict[str, str]:
    """Fetch multiple pages concurrently and return {url: cleaned_text}."""
    results: Dict[str, str] = {}

    async def _fetch(client: httpx.AsyncClient, url: str):
        try:
            resp = await client.get(url, headers=_DEFAULT_HEADERS, timeout=timeout)
            resp.raise_for_status()
            results[url] = _clean_html(resp.text)
        except Exception:
            results[url] = ""

    async with httpx.AsyncClient() as client:
        await asyncio.gather(*[_fetch(client, url) for url in urls])

    return results
