# backend/app/tools/search.py
import os
import re
from typing import Dict, List, Optional

from duckduckgo_search import DDGS
from app.config.settings import get_settings


def _get_allowed_domains() -> Optional[List[str]]:
    raw = os.getenv("ALLOWED_DOMAINS", "").strip()
    if not raw:
        return None
    return [d.strip().lower() for d in raw.split(",") if d.strip()]


def _domain_from_url(url: str) -> str:
    match = re.search(r"https?://([^/]+)", url)
    return (match.group(1) if match else "").lower()


def _is_allowed(url: str, allowed_domains: Optional[List[str]]) -> bool:
    if not allowed_domains:
        return True
    domain = _domain_from_url(url)
    return any(domain == d or domain.endswith("." + d) for d in allowed_domains)


def search_web(query: str, max_results: int = 5, allowed_domains: Optional[List[str]] = None) -> List[Dict[str, str]]:
    """Search the web using DuckDuckGo and return basic result metadata."""
    results: List[Dict[str, str]] = []
    if allowed_domains is None:
        settings = get_settings()
        allowed_domains = settings.allowed_domains or _get_allowed_domains()
    try:
        with DDGS() as ddgs:
            for item in ddgs.text(query, max_results=max_results):
                url = item.get("href") or item.get("url")
                if not url:
                    continue
                if not _is_allowed(url, allowed_domains):
                    continue
                results.append(
                    {
                        "title": item.get("title", ""),
                        "href": url,
                        "snippet": item.get("body", ""),
                    }
                )
    except Exception:
        return []
    return results
