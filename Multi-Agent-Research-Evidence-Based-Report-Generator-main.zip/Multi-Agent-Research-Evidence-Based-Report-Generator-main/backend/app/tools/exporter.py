# backend/app/tools/exporter.py
import os
from datetime import datetime
from typing import Dict

try:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
except Exception:  # pragma: no cover
    letter = None
    getSampleStyleSheet = None
    Paragraph = None
    SimpleDocTemplate = None
    Spacer = None
    Table = None
    TableStyle = None
    colors = None


def _ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)


def _timestamp() -> str:
    return datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")


def save_markdown(topic: str, content: str, output_dir: str) -> str:
    _ensure_dir(output_dir)
    filename = f"report_{_timestamp()}_{_safe_slug(topic)}.md"
    path = os.path.join(output_dir, filename)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    return path


def _escape_text(text: str) -> str:
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
    )


def _inline_markdown(text: str) -> str:
    # Bold: **text**
    text = _escape_text(text)
    text = text.replace("**", "§§BOLD§§")
    parts = text.split("§§BOLD§§")
    if len(parts) > 1:
        rebuilt = []
        bold = False
        for part in parts:
            if bold:
                rebuilt.append(f"<b>{part}</b>")
            else:
                rebuilt.append(part)
            bold = not bold
        text = "".join(rebuilt)

    # Italic: *text*
    text = text.replace("*", "§§ITALIC§§")
    parts = text.split("§§ITALIC§§")
    if len(parts) > 1:
        rebuilt = []
        italic = False
        for part in parts:
            if italic:
                rebuilt.append(f"<i>{part}</i>")
            else:
                rebuilt.append(part)
            italic = not italic
        text = "".join(rebuilt)

    # Inline code: `code`
    text = text.replace("`", "§§CODE§§")
    parts = text.split("§§CODE§§")
    if len(parts) > 1:
        rebuilt = []
        code = False
        for part in parts:
            if code:
                rebuilt.append(f"<font face='Courier'>{part}</font>")
            else:
                rebuilt.append(part)
            code = not code
        text = "".join(rebuilt)

    return text


def _format_markdown_line(line: str) -> str:
    return _inline_markdown(line.rstrip())


def _is_table_separator(line: str) -> bool:
    stripped = line.strip()
    if not stripped or "|" not in stripped:
        return False
    parts = [p.strip() for p in stripped.strip("|").split("|")]
    return all(p and set(p) <= {"-"} for p in parts)


def _parse_table(lines, start_index: int):
    header = lines[start_index].strip().strip("|").split("|")
    header = [h.strip() for h in header]
    rows = []
    i = start_index + 2
    while i < len(lines):
        line = lines[i]
        if "|" not in line or not line.strip():
            break
        row = [c.strip() for c in line.strip().strip("|").split("|")]
        rows.append(row)
        i += 1
    return [header] + rows, i


def save_pdf(topic: str, content: str, output_dir: str) -> str:
    if SimpleDocTemplate is None:
        return ""
    _ensure_dir(output_dir)
    filename = f"report_{_timestamp()}_{_safe_slug(topic)}.pdf"
    path = os.path.join(output_dir, filename)

    doc = SimpleDocTemplate(path, pagesize=letter, leftMargin=54, rightMargin=54, topMargin=54, bottomMargin=54)
    styles = getSampleStyleSheet()
    body = styles["BodyText"]
    body.leading = 14
    h1 = ParagraphStyle("H1", parent=styles["Heading1"], fontSize=18, spaceAfter=10)
    h2 = ParagraphStyle("H2", parent=styles["Heading2"], fontSize=15, spaceAfter=8)
    h3 = ParagraphStyle("H3", parent=styles["Heading3"], fontSize=13, spaceAfter=6)
    story = []

    lines = content.splitlines()
    i = 0
    while i < len(lines):
        raw_line = lines[i]
        if not raw_line.strip():
            story.append(Spacer(1, 10))
            i += 1
            continue

        if "|" in raw_line and i + 1 < len(lines) and _is_table_separator(lines[i + 1]):
            table_data, next_i = _parse_table(lines, i)
            if Table is not None:
                table = Table(table_data, hAlign="LEFT")
                table.setStyle(
                    TableStyle(
                        [
                            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#eef2ff")),
                            ("TEXTCOLOR", (0, 0), (-1, 0), colors.HexColor("#1f2937")),
                            ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#cbd5f5")),
                            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f8fafc")]),
                            ("VALIGN", (0, 0), (-1, -1), "TOP"),
                        ]
                    )
                )
                story.append(table)
                story.append(Spacer(1, 10))
            i = next_i
            continue

        line = _format_markdown_line(raw_line)
        if line.startswith("### "):
            story.append(Paragraph(line[4:], h3))
        elif line.startswith("## "):
            story.append(Paragraph(line[3:], h2))
        elif line.startswith("# "):
            story.append(Paragraph(line[2:], h1))
        elif line.startswith("- ") or line.startswith("* ") or line.startswith("+ "):
            story.append(Paragraph(f"• {line[2:]}", body))
        elif line[:3].isdigit() and line[3:5] == ". ":
            story.append(Paragraph(line, body))
        elif line.endswith(":") and len(line) <= 80:
            story.append(Paragraph(f"<b>{line[:-1]}</b>", h3))
        else:
            story.append(Paragraph(line, body))
        story.append(Spacer(1, 4))
        i += 1

    doc.build(story)
    return path


def _safe_slug(text: str) -> str:
    safe = "".join(ch if ch.isalnum() else "-" for ch in text.strip().lower())
    safe = "-".join([p for p in safe.split("-") if p])
    return safe[:50] if safe else "report"


def export_report(topic: str, content: str, output_dir: str, export_pdf: bool) -> Dict[str, str]:
    outputs = {"markdown": save_markdown(topic, content, output_dir)}
    if export_pdf:
        outputs["pdf"] = save_pdf(topic, content, output_dir)
    return outputs
