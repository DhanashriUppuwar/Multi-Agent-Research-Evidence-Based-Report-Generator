# backend/app/tools/credibility.py
import re
from typing import List


def _domain_from_url(url: str) -> str:
    match = re.search(r"https?://([^/]+)", url)
    return (match.group(1) if match else "").lower()


def credibility_score(url: str, high_trust_domains: List[str]) -> float:
    domain = _domain_from_url(url)
    if any(domain == d or domain.endswith("." + d) for d in high_trust_domains):
        return 1.0
    if domain.endswith(".gov") or domain.endswith(".edu") or domain.endswith(".int"):
        return 0.9
    return 0.7
