# backend/app/schemas/report.py
from typing import Any, Dict, List
from pydantic import BaseModel


class ReportRequest(BaseModel):
    topic: str


class ReportResponse(BaseModel):
    topic: str
    report: str
    citations: List[str]
    coverage_score: float
    verified: bool
    report_id: str
    outputs: Dict[str, str]
    research_status: Dict[str, Any]
