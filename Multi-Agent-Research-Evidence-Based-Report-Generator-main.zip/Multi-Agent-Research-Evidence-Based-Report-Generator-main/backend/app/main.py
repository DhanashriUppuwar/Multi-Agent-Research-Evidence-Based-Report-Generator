# backend/app/main.py
from pathlib import Path

from dotenv import load_dotenv
from fastapi import FastAPI

_ROOT = Path(__file__).resolve().parents[2]
load_dotenv(_ROOT / ".env")

from app.api.routes import router as api_router

app = FastAPI(title="Multi-Agent Research Report Generator", version="0.1.0")
app.include_router(api_router)


@app.get("/health")
def health():
    return {"status": "ok"}
