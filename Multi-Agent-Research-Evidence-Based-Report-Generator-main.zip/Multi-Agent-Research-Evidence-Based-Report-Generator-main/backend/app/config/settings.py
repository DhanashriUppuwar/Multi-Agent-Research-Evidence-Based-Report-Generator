# backend/app/config/settings.py
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import List


_ROOT = Path(__file__).resolve().parents[3]


def _get_list(name: str) -> List[str]:
    raw = os.getenv(name, "").strip()
    if not raw:
        return []
    return [item.strip().lower() for item in raw.split(",") if item.strip()]


def _resolve_path(path_value: str) -> str:
    candidate = Path(path_value)
    if candidate.is_absolute():
        return str(candidate)
    return str((_ROOT / candidate).resolve())


@dataclass(frozen=True)
class Settings:
    max_search_results: int
    min_text_length: int
    chunk_size: int
    chunk_overlap: int
    coverage_threshold: float
    max_retries: int
    top_k_evidence: int
    min_source_diversity: float
    allowed_domains: List[str] = field(default_factory=list)
    high_trust_domains: List[str] = field(default_factory=list)
    chroma_persist_dir: str = ""
    state_dir: str = ""
    output_dir: str = ""
    export_pdf: bool = False


def get_settings() -> Settings:
    return Settings(
        max_search_results=int(os.getenv("MAX_SEARCH_RESULTS", "4")),
        min_text_length=int(os.getenv("MIN_TEXT_LENGTH", "800")),
        chunk_size=int(os.getenv("CHUNK_SIZE", "800")),
        chunk_overlap=int(os.getenv("CHUNK_OVERLAP", "120")),
        coverage_threshold=float(os.getenv("COVERAGE_THRESHOLD", "0.7")),
        max_retries=int(os.getenv("MAX_RETRIES", "1")),
        top_k_evidence=int(os.getenv("TOP_K_EVIDENCE", "5")),
        min_source_diversity=float(os.getenv("MIN_SOURCE_DIVERSITY", "0.3")),
        allowed_domains=_get_list("ALLOWED_DOMAINS"),
        high_trust_domains=_get_list("HIGH_TRUST_DOMAINS"),
        chroma_persist_dir=_resolve_path(
            os.getenv("CHROMA_PERSIST_DIR", "backend/app/data/chroma")
        ),
        state_dir=_resolve_path(os.getenv("STATE_DIR", "backend/app/data/state")),
        output_dir=_resolve_path(os.getenv("OUTPUT_DIR", "backend/app/outputs")),
        export_pdf=os.getenv("EXPORT_PDF", "0") == "1",
    )
