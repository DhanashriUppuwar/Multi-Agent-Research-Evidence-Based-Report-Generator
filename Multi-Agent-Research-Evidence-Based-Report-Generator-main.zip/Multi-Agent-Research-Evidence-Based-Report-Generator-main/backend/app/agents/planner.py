# backend/app/agents/planner.py
from app.graph.state import ResearchState


def plan_outline(state: ResearchState):
    topic = state["topic"]
    outline = {
        "sections": [
            {
                "title": "Overview",
                "objective": f"Provide background and context for {topic}.",
                "questions": ["What is it?", "Why does it matter?"],
                "priority": "High",
            },
            {
                "title": "Key Findings",
                "objective": "Summarize the most important findings.",
                "questions": ["What are the key points?"],
                "priority": "High",
            },
            {
                "title": "Limitations",
                "objective": "Identify gaps, risks, and uncertainty.",
                "questions": ["What are the limitations?"],
                "priority": "Medium",
            },
        ]
    }
    return {"outline": outline}
