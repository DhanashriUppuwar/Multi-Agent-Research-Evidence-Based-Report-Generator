# backend/app/agents/writer.py
from typing import Any, Dict, List

from app.config.settings import get_settings
from app.core.llm_loader import initialize_llm
from app.tools.vectorstore import query_chunks


def write_report(state):
    settings = get_settings()
    topic = state["topic"]
    outline = state.get("outline", {})

    evidence_sections = []
    references: List[Dict[str, Any]] = []
    reference_index: Dict[str, int] = {}
    reference_entries: List[str] = []

    for section in outline.get("sections", []):
        section_title = section.get("title", "")
        query = f"{topic} {section_title}"
        results = query_chunks(
            topic,
            query,
            n_results=settings.top_k_evidence,
            where={"section": section_title},
        )

        section_evidence = []
        for item in results:
            meta = item.get("metadata", {})
            references.append(meta)
            url = meta.get("source_url", "")
            if url and url not in reference_index:
                reference_index[url] = len(reference_index) + 1
                title = meta.get("title") or url
                reference_entries.append(f"{title} - {url}")
            ref_idx = reference_index.get(url)
            ref_tag = f"[{ref_idx}]" if ref_idx else "[?]"
            section_evidence.append(f"{ref_tag} {item.get('document', '')}")

        evidence_sections.append(
            f"Section: {section_title}\nEvidence:\n" + "\n".join(section_evidence)
        )

    citations = [url for url in reference_index.keys()]

    try:
        llm = initialize_llm()
        prompt = (
            "Write a concise, structured research report with citations. "
            "Use the provided outline and evidence snippets. Cite using [n].\n\n"
            f"Topic: {topic}\n"
            f"Outline: {outline}\n\n"
            "Evidence:\n"
            + "\n\n".join(evidence_sections)
        )
        response = llm.invoke(prompt)
        report = getattr(response, "content", str(response))
    except Exception:
        report = (
            f"# {topic}\n\n"
            "## Executive Summary\n"
            "This is a placeholder report generated without a configured LLM.\n\n"
            "## Findings\n"
            "- Add evidence-backed findings here.\n\n"
            "## Limitations\n"
            "- Add limitations and uncertainty notes here.\n\n"
            "## Conclusion\n"
            "- Add a concise conclusion here.\n"
        )

    if reference_entries:
        report += "\n\n## References\n"
        for idx, entry in enumerate(reference_entries, start=1):
            report += f"[{idx}] {entry}\n"

    return {"report": report, "citations": citations}
