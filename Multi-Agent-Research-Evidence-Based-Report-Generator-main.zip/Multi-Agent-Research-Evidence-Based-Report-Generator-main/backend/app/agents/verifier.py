# backend/app/agents/verifier.py
from typing import Any, Dict, List

from app.config.settings import get_settings
from app.tools.vectorstore import query_chunks


def verify(state):
    settings = get_settings()
    topic = state["topic"]
    outline = state.get("outline", {})

    total_questions = 0
    covered_questions = 0
    insufficient: List[Dict[str, Any]] = []
    unique_domains = set()
    total_sources = 0

    for section in outline.get("sections", []):
        section_title = section.get("title", "")
        for question in section.get("questions", []):
            total_questions += 1
            results = query_chunks(
                topic,
                question,
                n_results=3,
                where={"section": section_title},
            )
            if results:
                covered_questions += 1
                for item in results:
                    meta = item.get("metadata", {})
                    url = meta.get("source_url", "")
                    if url:
                        total_sources += 1
                        domain = url.split("/")[2] if "//" in url else url
                        unique_domains.add(domain)
            else:
                insufficient.append({"section": section_title, "question": question})

    coverage_score = (covered_questions / total_questions) if total_questions else 0.0
    diversity_score = (
        (len(unique_domains) / total_sources) if total_sources else 0.0
    )

    verified = (
        coverage_score >= settings.coverage_threshold
        and diversity_score >= settings.min_source_diversity
    )

    return {
        "coverage_score": round(coverage_score, 3),
        "verified": verified,
        "research_status": {
            **state.get("research_status", {}),
            "insufficient": insufficient,
            "diversity_score": round(diversity_score, 3),
        },
    }
