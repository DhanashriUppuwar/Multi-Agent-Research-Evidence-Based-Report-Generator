# backend/app/agents/researcher.py
import asyncio
from datetime import datetime
from typing import Dict, List, Tuple

from app.config.settings import get_settings
from app.tools.chunker import chunk_text
from app.tools.credibility import credibility_score
from app.tools.loader import load_web_page, load_web_pages
from app.tools.search import search_web
from app.tools.vectorstore import store_embeddings


def _build_queries(topic: str, question: str) -> List[str]:
    return [f"{topic} {question}", f"{question} {topic}"]


def research(state):
    settings = get_settings()
    topic = state["topic"]
    outline = state.get("outline", {})
    seen_urls = set(state.get("citations", []))

    total_chunks = 0
    url_jobs: List[Tuple[str, str, str, str]] = []
    for section in outline.get("sections", []):
        section_title = section.get("title", "")
        for question in section.get("questions", []):
            for query in _build_queries(topic, question):
                results = search_web(query, max_results=settings.max_search_results)
                for item in results:
                    url = item.get("href")
                    if not url or url in seen_urls:
                        continue
                    url_jobs.append(
                        (url, section_title, question, item.get("title", ""))
                    )

    urls = [job[0] for job in url_jobs]
    fetched: Dict[str, str] = {}
    try:
        fetched = asyncio.run(load_web_pages(urls))
    except RuntimeError:
        for url in urls:
            try:
                fetched[url] = load_web_page(url)
            except Exception:
                fetched[url] = ""

    for url, section_title, question, title in url_jobs:
        text = fetched.get(url, "")
        if len(text) < settings.min_text_length:
            continue

        chunks = chunk_text(
            text,
            chunk_size=settings.chunk_size,
            overlap=settings.chunk_overlap,
        )
        timestamp = datetime.utcnow().isoformat() + "Z"
        score = credibility_score(url, settings.high_trust_domains)
        metadatas = []
        for _ in chunks:
            metadatas.append(
                {
                    "topic": topic,
                    "section": section_title,
                    "question": question,
                    "source_url": url,
                    "title": title,
                    "timestamp": timestamp,
                    "credibility": score,
                }
            )

        stored = store_embeddings(topic, chunks, metadatas)
        total_chunks += stored
        seen_urls.add(url)

    retry_count = state.get("retry_count", 0) + 1
    return {
        "research_status": {
            "last_run": datetime.utcnow().isoformat() + "Z",
            "chunks_added": total_chunks,
        },
        "retry_count": retry_count,
        "citations": sorted(seen_urls),
    }
