# frontend/app.py
import os
from pathlib import Path
from datetime import datetime

from dotenv import load_dotenv

import requests
import streamlit as st

st.set_page_config(page_title="Research Intelligence Portal", layout="wide")

_CSS = """
<style>
    :root {
        --bg: #0a0f1a;
        --panel: #121a2b;
        --panel-2: #0f1626;
        --text: #e8edf7;
        --muted: #9fb1d1;
        --accent: #3b82f6;
        --accent-2: #22d3ee;
        --border: #1e2a44;
    }
    .stApp {
        background: radial-gradient(1200px 600px at 20% -10%, #1b2b4a 0%, #0a0f1a 55%);
        color: var(--text);
    }
    header, footer, #MainMenu { visibility: hidden; }
    .hero {
        padding: 28px 28px 18px 28px;
        border-radius: 18px;
        background: linear-gradient(135deg, rgba(59,130,246,0.18), rgba(34,211,238,0.08));
        border: 1px solid var(--border);
        margin-bottom: 18px;
    }
    .hero h1 {
        font-size: 34px;
        margin: 0 0 6px 0;
        letter-spacing: 0.2px;
    }
    .hero p {
        color: var(--muted);
        margin: 0;
        font-size: 15px;
    }
    .card {
        background: var(--panel);
        border: 1px solid var(--border);
        border-radius: 16px;
        padding: 18px;
        margin-bottom: 16px;
    }
    .subtle {
        color: var(--muted);
        font-size: 13px;
    }
    .badge {
        display: inline-block;
        padding: 4px 10px;
        border-radius: 999px;
        background: rgba(59,130,246,0.15);
        border: 1px solid rgba(59,130,246,0.35);
        font-size: 12px;
        color: #c7dbff;
        margin-right: 6px;
    }
    .stTextArea textarea {
        background: var(--panel-2);
        border: 1px solid var(--border);
        color: var(--text);
    }
    .stButton button {
        background: linear-gradient(135deg, var(--accent), var(--accent-2));
        color: #0b1020;
        border: none;
        border-radius: 12px;
        padding: 10px 18px;
        font-weight: 600;
    }
    .report {
        background: #0e1526;
        border: 1px solid var(--border);
        border-radius: 16px;
        padding: 20px;
    }
    .divider {
        height: 1px;
        background: var(--border);
        margin: 14px 0;
    }
</style>
"""

st.markdown(_CSS, unsafe_allow_html=True)

_ROOT = Path(__file__).resolve().parents[1]
load_dotenv(_ROOT / ".env")

backend_url = os.getenv("BACKEND_URL", "http://localhost:8000")
output_dir = Path(os.getenv("OUTPUT_DIR", "backend/app/outputs"))

st.markdown(
    """
    <div class="hero">
        <span class="badge">Research Intelligence</span>
        <span class="badge">Evidence-Backed</span>
        <h1>Research Intelligence Portal</h1>
        <p>Generate structured, citation-backed research reports with multi-agent orchestration.</p>
    </div>
    """,
    unsafe_allow_html=True,
)

left, right = st.columns([3, 2])

with left:
    st.markdown('<div class="card">', unsafe_allow_html=True)
    topic = st.text_area(
        "Research Topic",
        height=160,
        placeholder="Example: Agentic AI systems in enterprise automation (2020–2025)",
    )
    st.markdown('<div class="subtle">Tip: Be specific about scope, timeframe, and domain.</div>', unsafe_allow_html=True)
    run = st.button("Generate Report")
    st.markdown("</div>", unsafe_allow_html=True)

with right:
    st.markdown('<div class="card">', unsafe_allow_html=True)
    st.markdown("**Output Options**")
    allow_pdf = st.checkbox("Enable PDF download if available", value=True)
    st.markdown('<div class="divider"></div>', unsafe_allow_html=True)
    st.markdown("**Report History**")
    history_items = []
    try:
        history_resp = requests.get(f"{backend_url}/history", timeout=10)
        if history_resp.ok:
            history_items = history_resp.json().get("items", [])
    except Exception:
        history_items = []

    if history_items:
        labels = [
            f"{item['name']} • {datetime.fromisoformat(item['updated_at']).strftime('%Y-%m-%d %H:%M')}"
            for item in history_items
        ]
        selected = st.selectbox("Recent reports", options=list(range(len(history_items))), format_func=lambda i: labels[i])
        if st.button("Open Selected Report"):
            name = history_items[selected].get("name")
            try:
                detail_resp = requests.get(f"{backend_url}/history/{name}", timeout=10)
                if detail_resp.ok:
                    detail = detail_resp.json()
                    st.session_state["selected_report_content"] = detail.get("content", "")
                    st.session_state["selected_pdf"] = detail.get("pdf")
                else:
                    st.session_state["selected_report_content"] = ""
                    st.session_state["selected_pdf"] = ""
            except Exception:
                st.session_state["selected_report_content"] = ""
                st.session_state["selected_pdf"] = ""
    else:
        st.caption("No saved reports yet.")
    st.markdown('<div class="divider"></div>', unsafe_allow_html=True)
    st.markdown("**Quality Signals**")
    st.markdown('<div class="subtle">Coverage, verification, and citations are shown after generation.</div>', unsafe_allow_html=True)
    st.markdown("</div>", unsafe_allow_html=True)

if run:
    st.session_state.pop("selected_report_content", None)
    st.session_state.pop("selected_pdf", None)
    if not topic.strip():
        st.warning("Please enter a research topic.")
    else:
        with st.spinner("Synthesizing report and validating evidence..."):
            resp = requests.post(
                f"{backend_url}/generate-report",
                json={"topic": topic},
                timeout=180,
            )
        if resp.ok:
            data = resp.json()
            report_text = data.get("report", "")
            outputs = data.get("outputs", {})

            st.markdown('<div class="report">', unsafe_allow_html=True)
            st.markdown(report_text)
            st.markdown("</div>", unsafe_allow_html=True)

            st.markdown("### Report Details")
            coverage = data.get("coverage_score")
            verified = data.get("verified")
            if verified:
                st.success(f"Verified evidence coverage. Score: {coverage}")
            else:
                st.warning(f"Evidence coverage below threshold. Score: {coverage}")
            st.write(
                {
                    "report_id": data.get("report_id"),
                    "coverage_score": data.get("coverage_score"),
                    "verified": data.get("verified"),
                    "citations": len(data.get("citations", [])),
                }
            )

            st.markdown("### Sources")
            citations = data.get("citations", [])
            if citations:
                st.markdown("\n".join([f"- {url}" for url in citations]))
            else:
                st.caption("No sources available.")

            st.markdown("### Downloads")
            if report_text:
                st.download_button(
                    label="Download Report (Markdown)",
                    data=report_text,
                    file_name="report.md",
                    mime="text/markdown",
                )

            if allow_pdf:
                pdf_path = outputs.get("pdf")
                if pdf_path and Path(pdf_path).exists():
                    pdf_bytes = Path(pdf_path).read_bytes()
                    st.download_button(
                        label="Download Report (PDF)",
                        data=pdf_bytes,
                        file_name=Path(pdf_path).name,
                        mime="application/pdf",
                    )
                else:
                    st.caption("PDF export is disabled or unavailable.")
        else:
            st.error(f"Backend error: {resp.status_code} - {resp.text}")

if "selected_report_content" in st.session_state and not run:
    content = st.session_state.get("selected_report_content", "")
    if content:
        st.markdown("### Selected Report")
        st.markdown(content)
        selected_pdf = st.session_state.get("selected_pdf")
        if selected_pdf:
            pdf_path = Path(selected_pdf)
            if pdf_path.exists():
                st.download_button(
                    label="Download Selected PDF",
                    data=pdf_path.read_bytes(),
                    file_name=pdf_path.name,
                    mime="application/pdf",
                )
